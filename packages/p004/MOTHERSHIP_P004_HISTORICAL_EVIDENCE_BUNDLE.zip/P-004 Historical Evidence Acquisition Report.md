# P-004 Historical Evidence Acquisition Report

**Scope:** original-byte acquisition and verification only. The 21-advisory scope came solely from the supplied P-003 evidence ZIP; no advisory research was repeated and no source URL was inferred.

## Advisory acquisition and provenance

- Input: `MOTHERSHIP_P003_HISTORICAL_EVIDENCE.zip` (15,595 bytes; SHA-256 `734c30752d0396d420f18141d5d75f3f8b408baac6fcaf074d2a08cfbbf61925`; ZIP CRC test passed).
- P-003 reconciliation: all **21/21 advisory identifiers and canonical URLs** match the corresponding P-003 finding records exactly.
- Advisory responses: **21 acquired, 0 inaccessible, 0 blocked**; all returned HTTP **200**. The preserved response bodies total **118,981 bytes**. They were written without text decoding or newline normalization to `P004_original_advisories/FreeBSD-SA-*.asc`.
- `P004_source_manifest.jsonl` records each original URL, HTTP status, request/retrieval timestamps, final URL, selected response headers, exact byte count, SHA-256, P-003 line/hash provenance, and any redirect bodies. `P004_sha256sums.txt` provides independently reproducible hashes for every preserved HTTP/FTP response-body file.

## Signatures and key trust

All **21/21** acquired advisories contain clear-signed message and signature block markers; the original signature blocks are preserved in their `.asc` bodies. Signature-packet issuer IDs are recorded only as unverified metadata. Cryptographic signature verification was **not attempted**: P-003 supplied no independently authenticated historical signing-key fingerprint. The `ftp://freebsd.org/pub/CERT/public_key.asc` reference found in the advisory text is recorded but is not treated as independent authentication, and no key was imported or trusted. Key trust therefore remains **UNKNOWN / UNVERIFIED**.

## Inline patches and original patch files

P-003 reported **16** advisories with inline patches. A scan of the acquired original bytes for historical context-diff and unified-diff markers (`***`, `---`, `Index:`, `RCS file:`, revision and diff lines) confirms inline patch material in **all 16**. The code remains inside the original signed `.asc` files; no extracted or reconstructed patch text is presented as an original patch file. P-003 lists **32** source-code path references; **30** exact path strings are present in the acquired bodies. P-003’s two SA-96:15 absolute source paths are not literal strings in the signed body. The original instead gives `Index: command.c` / `Index: chat.c` and RCS file paths under `/home/ncvs/src/usr.sbin/ppp/`; both forms are retained, and the path-form mapping remains explicitly unresolved. The per-advisory marker line numbers, source paths, patch URLs, and revisions are documented in `P004_patch_references.jsonl`.

The signed advisories cite **19 distinct** original FreeBSD CERT FTP patch directories. All 19 directory references were attempted at their exact `ftp://freebsd.org/pub/CERT/patches/...` locations. Each FTP control connection ended with `EOFError` before a server banner; **0 directories could be listed and 0 external patch files could be acquired**. Those are network/protocol access failures, not evidence that patch files are absent. No guessed HTTPS mirror or derived URL was used. These attempts and errors are itemized in the source manifest and unresolved ledger.

## Contradictions, revisions, and identifier caveats

P-003's conflicts and anomalies are retained, not silently corrected. They include the SA-96:01 workaround-command mismatch, SA-96:12 affected-version contradiction, and SA-96:21 advisory-year/announcement-field ambiguity. P-003's candidate CVE-2001-1252 relationship remains unverified; the Netscape later identifier remains unresolved. P-003 transcribed latest revision headers for selected advisories, but did not establish full prior revision histories. P-004 records the revision/date fields visible in the acquired originals while preserving the source's contradictions.

## License and redistribution uncertainty

P-003 noted the FreeBSD Documentation License and notice-preservation conditions, while flagging that applicability to each historical notice and included third-party patch/code needs review. P-004 preserves each notice verbatim and makes no legal conclusion. Redistribution outside this evidence package remains uncertain pending record-level rights review.

## Verification status

- **VERIFIED:** 21/21 HTTP 200 advisory bodies acquired; exact P-003 ID/URL match; original bodies' byte counts and SHA-256 values; 21 signature-block markers; all 16 P-003 inline-patch advisories show patch-format material in the preserved originals; every advisory is accounted for.
- **REPORTED:** P-003 source-code references, patch-directory URLs, revision notes, conflicts, identifier relationships, and licensing notes are carried forward as attributed records.
- **UNVERIFIED / INACCESSIBLE:** cryptographic signatures without independently authenticated keys; separate FTP patch files because the original FTP control connections failed; complete revision histories; redistribution rights.

The package is prepared for independent audit. `P004_unresolved.json` enumerates remaining items and the evidence needed to close them.
