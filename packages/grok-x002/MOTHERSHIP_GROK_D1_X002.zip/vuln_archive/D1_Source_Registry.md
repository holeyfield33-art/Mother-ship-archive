# D1 — Source Registry
**Collection started:** 2026-10-29
**Mission:** MOTHERSHIP-001 Global Vulnerability Intelligence Collection

## Official Vulnerability Databases

### NVD (National Vulnerability Database)
- URL: https://nvd.nist.gov/
- Data feeds: https://nvd.nist.gov/download.cfm (JSON 2.0 feeds, year-based, recent, modified)
- API: https://services.nvd.nist.gov/rest/json/cves/2.0 (rate-limited; API key recommended for bulk)
- Community mirror: https://github.com/fkie-cad/nvd-json-data-feeds (xz JSON feeds by year)
- Licensing: Public domain / US Gov work; attribution preferred
- Update: Nightly / continuous via API
- Status: Primary source; feeds partially transitioned from 1.1 to 2.0

### CVE Program / CVE List
- URL: https://www.cve.org/
- Bulk: https://github.com/CVEProject/cvelistV5 (CVE JSON 5.0, hourly deltas + daily baselines)
- Downloads page: https://www.cve.org/Downloads
- Licensing: CVE Program Terms of Use
- Status: Canonical CVE records

### GitHub Advisory Database
- URL: https://github.com/advisories
- Repo: https://github.com/github/advisory-database (OSV format)
- API: REST + GraphQL (https://docs.github.com/en/rest/security-advisories)
- Ecosystems: npm, pip, maven, go, rust, etc.
- Licensing: Open; community contributions
- Status: Strong for open-source package advisories; includes reviewed + unreviewed

### OSV (Open Source Vulnerabilities)
- URL: https://osv.dev/
- Bulk: gs://osv-vulnerabilities/ (GCS; all.zip + per-ecosystem all.zip); HTTP: https://storage.googleapis.com/osv-vulnerabilities/
- modified_id.csv for deltas
- Licensing: Open
- Status: Aggregates many sources (GHSA, PyPA, Go, RustSec, etc.)

### CISA KEV (Known Exploited Vulnerabilities)
- URL: https://www.cisa.gov/known-exploited-vulnerabilities-catalog
- JSON: https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json
- CSV: https://www.cisa.gov/sites/default/files/csv/known_exploited_vulnerabilities.csv
- GitHub mirror: https://github.com/cisagov/kev-data
- Collected: 2026-10-29 — 1764 entries, catalogVersion 2026.10.29
- Licensing: US Gov public
- Status: High-priority subset; actively maintained

### MITRE CWE
- URL: https://cwe.mitre.org/
- Downloads: https://cwe.mitre.org/data/downloads.html
- Latest XML: https://cwe.mitre.org/data/xml/cwec_latest.xml.zip (v5.0 collected 2026-10-29)
- CSV/XML views available
- Licensing: MITRE Terms of Use
- Status: Core weakness taxonomy

### CAPEC
- URL: https://capec.mitre.org/
- Status: Attack pattern mappings (to be bulk-collected)

## Aggregation & Enrichment Sources
- dbcve.org: Free CSV/API enriched CVE (https://dbcve.org/api/v1/export/)
- Vulners, Snyk, OpenCVE, CVE Details, CVEFind (to inventory)
- GitLab Advisory Database

## Source-Code / Patch Datasets (Research)
- CVEfixes: https://github.com/secureIT-project/CVEfixes + Zenodo (v1.0.8 to ~2024-07)
- MoreFixes: Larger dataset (~43k CVEs with fixes, 2026); Zenodo + GitHub
- Big-Vul, DiverseVul, Juliet Test Suite, NIST SARD, OWASP Benchmark, OSS-Fuzz
- security-patches-dataset, vfc_datasets aggregators
- Linux kernel bug-fix pairs (125k+ pairs)

## Access Notes
- Prefer official bulk/API over scraping.
- Respect rate limits (NVD API especially).
- Record licenses; do not redistribute restricted content beyond fair use/citation.
- No private or paywalled sources without explicit public access.

## Next Acquisition Priorities
1. Sample/partial NVD year feeds or API pagination for recent years
2. OSV all.zip or per-ecosystem zips (large)
3. GitHub advisory-database clone or API sampling
4. Full CWE parse + CAPEC
5. Inventory of academic datasets (CVEfixes download if feasible size-wise)
6. Vendor advisories (Microsoft, Google, Apache, etc.)

**Last updated:** 2026-10-29
