# D-004 Ecosystem Evidence Acquisition Report

**Generated (UTC):** 2026-10-31T03:48:38.014181+00:00
**Scope:** Original-byte acquisition, source revision pinning, record-count validation, and identifier overlap against the preserved C-002 baselines. No scanners, ingestion services, dashboards, or detection rules were built.

## Acquisition result

All four requested targets were acquired successfully from the supplied official URLs or repository remotes. Source archives were not normalized or rewritten. The two Git repositories were captured at matching full main-branch commit SHAs; their tarballs contain the cloned snapshot and shallow `.git` metadata, not full repository history.

| Source | Snapshot/revision | Preserved bytes | SHA-256 | Records / unique primary IDs | Integrity |
|---|---|---:|---|---:|---|
| Go Vulnerability Database | `1793312224714214` | 3,516,204 | `a1118204c33192c19510f39448d46590432e0b6d115abdcd3a39476b6dc71ea8` | 4,712 / 4,712 | PASS |
| PyPA Advisory Database | `8084f1659014e2e234765c6fa8d0be4a2bfb46d4` | 14,808,366 | `095db4aaf332d31b886e5d405340452fd41e037cfebe910355f43d9e37d7af7b` | 7,901 / 7,901 | PASS |
| RustSec Advisory Database | `2295466c4e9df26647fd67d8fa1c705ac2fc7f81` | 1,562,354 | `830ef8de119408f6b186f0e91ca4e7e8c4cafd8d3b6829ea3b8a1d4b55de6e40` | 1,375 / 1,375 | PASS |
| OSV Hackage ecosystem bulk ZIP | `1790692377837633` | 52,482 | `fb96b44a3496fa33e6b8381712f01c47482cceea0997da7a61b64e197e3735f5` | 33 / 33 | PASS |

### Count and revision details

- **Go vuln DB:** 4,712 `ID/*.json` vulnerability records; the 4,712 IDs in `index/vulns.json` exactly match the record-file IDs. ZIP CRC test passed; 4,715 total archive entries. GCS object generation `1793312224714214`; embedded `index/db.json` modified timestamp `2026-10-27T21:16:18Z`.
- **PyPA Advisory Database:** 7,901 YAML files under `vulns/`, 7,901 unique `id` values; remote `main` and cloned HEAD both `8084f1659014e2e234765c6fa8d0be4a2bfb46d4`. Primary IDs and aliases were extracted from YAML fields; full YAML schema validation was not run.
- **RustSec Advisory Database:** 1,375 Markdown advisories with TOML front matter; 1,375 unique IDs; remote `main` and cloned HEAD both `2295466c4e9df26647fd67d8fa1c705ac2fc7f81`. TOML front matter parsed; all filenames/IDs agree.
- **OSV Hackage:** 33 JSON records, 33 unique IDs; ZIP CRC test passed; 33 total entries. GCS object generation `1790692377837633`.

No expected record counts were supplied in the pasted D-003 acquisition commands; counts above were independently derived from the preserved source-native files. Acquisition windows and HTTP headers/remote refs are preserved in `acquisition_evidence/`.

## C-002 overlap check

The overlap scan compares exact primary identifiers and explicit alias identifiers against the saved C-002 CVE List V5, GitHub Advisory Database, OSV, and NVD snapshots. It is an identifier-link test, not semantic deduplication or a claim that two records have identical validity, root cause, affected scope, or status. Full per-record matching identifiers are in `D004_overlap_report.json`.

| D-004 target | Acquired records | CVE List V5 matches | GitHub Advisory matches | OSV matches | NVD matches |
| Go Vulnerability Database | 4712 | 4264 | 4650 | 4712 | 4264 |
| PyPA Advisory Database | 7901 | 7819 | 7793 | 7901 | 7819 |
| RustSec Advisory Database | 1375 | 561 | 820 | 1366 | 561 |
| OSV Hackage ecosystem bulk ZIP | 33 | 20 | 17 | 33 | 20 |

C-002 scanned baselines and expected sizes are recorded in the overlap JSON and sourced from `verification/C002_coverage_manifest.json`: CVE List V5 release `cve_2026-10-29_2300Z` (416267 records); GitHub Advisory Database commit `1cffb381571b702172a31eff57809b3d0fa1e13f` (397466 records); OSV generation `1793326731605169` (2332672 records); NVD (`209 pages, 416844 saved records, reconciled current total 416844).

## Repository TAR validation

- **PyPA:** TAR stream read completed; 9,591 members; 7,901 advisory YAML files in the TAR matched the pinned worktree byte-for-byte; embedded branch, shallow, and packed refs all match commit `8084f1659014e2e234765c6fa8d0be4a2bfb46d4`.
- **RustSec:** TAR stream read completed; 2,454 members; 1,375 advisory Markdown files in the TAR matched the pinned worktree byte-for-byte; embedded branch, shallow, and packed refs all match commit `2295466c4e9df26647fd67d8fa1c705ac2fc7f81`.
The machine-readable details are in `D004_repository_tar_validation.json`.

## License and redistribution notes

- PyPA snapshot contains a repository `LICENSE` headed “Attribution 4.0 International”; the notice is preserved inside the repository tarball. Whether it covers every imported advisory is not determined here.
- RustSec `LICENSE.txt` states a CC0-1.0 default and a CC BY 4.0 exception for GHSA-derived material. The preserved file named `LICENSES/CC-BY-4.0.txt` instead begins “Attribution-ShareAlike 4.0 International”; this discrepancy is unresolved. The source snapshot has 24 per-advisory `CC-BY-4.0` fields, 100 `CC0-1.0` fields, and 1,251 advisory records without an explicit per-record license field.
- The Go and OSV Hackage ZIPs contain no standalone LICENSE/COPYING/NOTICE entries; applicable terms remain unverified. No legal conclusion is made.

## Unresolved verification items

See `D004_unresolved.json` for evidence required to close the YAML schema, licensing, overlap-semantics, and shallow-history limitations. All four requested source targets were acquired; no acquisition failure is currently recorded.

## Integrity

`D004_sha256sums.txt` covers each preserved original source artifact, raw acquisition-evidence sidecars, and the TAR validation result. The handoff ZIP also has an external SHA-256 file. Recalculate with `sha256sum -c D004_sha256sums.txt` after extracting the package.

Supporting C-002 coverage and full overlap scan results are preserved under `verification/` and included in the checksum inventory.
