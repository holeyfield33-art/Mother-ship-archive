# P-003 Historical Primary-Evidence Recovery — Cycle Report

## Outcome
This package reconciles the visible P-002 history, not an asserted P-002 deliverable. The visible history supports 21 distinct FreeBSD advisory IDs (96:01, 96:02, 96:08–21, and 97:01–05) and three separately inspected Core Security advisory pages. The sum is 24 advisory pages; P-002's unqualified “24 findings” cannot safely be equated to 24 FreeBSD advisories or unique root causes. The asserted count of 19 directly inspected pages is not supported by the visible tool records. There were 41 successful distinct fetch URLs: 24 advisory pages and 17 indexes or landing pages. Their complete URL inventory is included in P003_reconciliation.json; no arbitrary 19-page subset is invented. No P-002 file-creation call appears in the visible history.

## Evidence preservation limitation
The web fetcher returned extracted primary text into conversation, often including full signed notice bodies and embedded diffs. It did not expose original HTTP response bytes as downloadable attachments or local files. The Python environment cannot access prior conversation text as file content. Consequently this ZIP contains no original source documents, zero raw records exported, zero source-byte hashes, and no claimed acquisition byte sizes. No hashes were fabricated. Two short publication-time identifier statements are exported as explicitly labeled excerpts. Their actual UTF-8 excerpt bytes are hashed; these are not full-document or remote-source hashes. The manifest lists each inspected FreeBSD notice as metadata-only with null path, byte count, and hash. P-003's byte-exact preservation acceptance criterion is not met.

FreeBSD's Documentation License allows redistribution of documentation source and compiled forms subject to retention of notice, conditions, and disclaimer. Applicability to each historical signed advisory and included third-party material still requires a record-level check. The published notices also state that their embedded patch text may be altered by signature or mailer software and direct readers to the original patch URLs. [web:162][web:112]

## Findings and counts
- FreeBSD source-specific advisory entries: 21. Each has its own FreeBSD-SA identifier, canonical URL, Announced date, and header affected-version transcription. Seven latest Revised headers are transcribed; earlier revision history is not recovered.
- Other Core Security primary advisory pages: 3; these are separate from the 21 FreeBSD notices. Two are the reports originally marked no CVE; the Microsoft PhoneBook report already listed CVE-2000-1089.
- Advisory pages reconstructed: 24. Unique vulnerability/root-cause count is not safely equivalent: SA-96:20 groups several program flaws; SA-96:09 and SA-96:10 expressly describe distinct issues.
- Newly captured/exported original files: 0. Source-code path references recovered from advisory text: 32 references across 16 advisories; none is a newly verified immutable repository link. Full fixing commits: 0. Patch files preserved: 0. Patch diffs were visible within extracted source responses but not exported as independent original files.

## Core Security identifier reconciliation
The PGP Keyserver advisory says “CVE Name: None currently assigned” and “Bugtraq ID: None currently assigned.” NVD records a related CGI authentication bypass as CVE-2001-1252, but its direct-cgi-bin-path description differs from the Core extension-omission mechanism. This is a candidate only, not a verified alias. The status remains NO_CVE_AT_PUBLICATION; no permanent no-CVE claim is made. [web:96][web:134]

The Netscape server DoS report says “CVE Name: Non currently assigned” and gives Bugtraq ID 1867. Later Netscape DoS identifiers were inspected, but the candidate descriptions differ in trigger or affected product; none was verified as an alias for the DSGW `context`-parameter exception. Status remains NO_CVE_AT_PUBLICATION; later alias unresolved. [web:99][web:193][web:174][web:194]

The third Core page, Microsoft PhoneBook Server overflow, explicitly lists CVE-2000-1089 and is not a non-CVE-at-publication item. [web:94]

## Historical source expansion completed at index level
SEI’s archive page lists yearly CERT advisory collections from 1988 through 2004. CERT/CC's Vulnerability Data Archive describes a historical dataset from approximately May 1998 to 2020-06-03, says it is incomplete, and notes only about 6% of reports became published Vulnerability Notes; the repository was archived in May 2024 and supplanted by VINCE. OpenBSD describes its 1996–1997 audit history and release-indexed advisories. Openwall oss-security and SecLists Full Disclosure/Bugtraq archives were inspected as indexes only. Individual messages and annual CERT source documents were not acquired. [web:29][web:175][web:110][web:176][web:177][web:36]

## Next continuation steps
1. In a byte-capable environment, fetch each canonical `.asc` file directly, record UTC retrieval timestamp, exact bytes, byte count, SHA-256, response headers, and license note; verify PGP signatures where keys are available. Never hash the extracted text as though it were the source file.
2. Acquire the linked original FreeBSD patch directories or repository revisions and verify the advisory's RCS revision identifiers against the patch. Retain advisory patch excerpts and external patch files as separate evidence objects.
3. Download SEI annual reports and CERT VDA's last release, pin the Git commit and dataset hashes, then compare with VINCE for post-2020 coverage. Preserve the VDA's own warning about incomplete reports and its report/vendor-record distinction. [web:175]
4. Resolve the Netscape DSGW DoS alias from the original Bugtraq message/Bugtraq ID 1867 or archived advisory. Keep CVE-2001-0251, CVE-2000-1025, and nearby IDs as non-matches unless primary evidence changes.
5. Recover per-record dates, affected versions, and embedded patch markers from complete files; count unique vulnerabilities only after splitting aggregate advisories and documenting relationships.

## Acceptance status and cross-team limitation
Partial completion only: reconciliation and acquisition-ready source manifest delivered; original-byte acquisition gate is NOT met. Manus C-002 was not provided, so overlap is unknown and no cross-team nonduplication is claimed. Source extraction is accessible, not remotely inaccessible. The two exported statement excerpts are not raw advisory records.
