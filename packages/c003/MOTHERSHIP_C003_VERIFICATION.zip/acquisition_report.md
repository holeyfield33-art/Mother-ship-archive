# MOTHERSHIP C-002 — Acquisition Handoff

**Acquisition window:** 2026-10-30 00:25–03:13 UTC  
**Status:** All four requested baselines acquired and accounted for. The NVD total changed during pagination; the final page span was reconciled to a fresh current total before marking it complete.

## Baseline coverage

- **CVE List V5:** Downloaded the official daily full baseline from release `cve_2026-10-29_2300Z`. The nested archive contains **416,267 CVE JSON records and 416,267 unique CVE identifiers**. Records include **18,842 rejected** entries. The two non-record control JSON files are excluded from the vulnerability count. Both outer and nested ZIP CRCs passed.
- **GitHub Advisory Database:** Archived all tracked files at pinned `main` commit `1cffb381571b702172a31eff57809b3d0fa1e13f`. The snapshot contains **397,466 advisory JSON records and 397,466 unique GHSA IDs**, including **1,250 withdrawn** advisories. This is a complete content snapshot at that commit, not the full Git history.
- **OSV:** Downloaded the official full `all.zip` archive at GCS generation `1793326731605169`. It contains **2,332,672 parsed JSON records and unique OSV IDs**, including **107,552 withdrawn** records. Its MD5 matches the upstream GCS metadata; the SHA-256 is in the integrity manifest. OSV documents that this export includes all ecosystems and withdrawn records. [3]
- **NVD:** Saved **209 contiguous API pages** containing **416,844 records and 416,844 unique CVE IDs**. Page 0 initially reported 416,807 records; the final page and a fresh total-only response reported 416,844. Every page start index from 0 through 416,000 is present, the final page contains the remaining 844 records, and no page failure remains unresolved. The increase of 37 during the live sweep is retained in the checkpoint and raw reconciliation response. [4] [5]
- **NVD incremental update:** Captured **1,856 records** in a distinct modified-date window recorded in `checkpoints/nvd_incremental.json`; the raw API page is retained separately from the baseline.
- **Cycle 01 originals:** The three original NVD, GitHub, and CISA JSON responses were copied byte-for-byte. All three copied SHA-256 digests match Cycle 01’s metadata.

## Checkpoints, hashes, and errors

`checkpoints/nvd_api.json` records all page starts, the starting and reconciled totals, and completion status. Two NVD requests briefly ended with remote connection closures; both pages were retried and validated. The error ledger retains those transient events and the recovered page indices. An initial NVD run was terminated by the environment after two hours at `startIndex=336000`; acquisition resumed from that checkpoint. No page failure remains unresolved.

The first OSV object-by-object listing reached 1,647,000 objects but did not download individual records. It was stopped in favor of OSV’s documented full-database `all.zip`, which was downloaded and verified. The GitHub working-tree checkout hit a filesystem “Too many links” error; instead, the complete tracked content was archived from the pinned Git commit. These events and their recovery paths are recorded in `logs/collection_errors.jsonl`.

`SHA256SUMS.txt` and `sha256_manifest.jsonl` provide hashes and byte sizes. `raw_file_manifest.jsonl` adds source URLs, revisions, retrieval timestamps, and NVD page indices. Paths in these checksum and provenance lists are relative to the archive’s top directory. `coverage_manifest.json` contains exact counts, unique identifiers, source-state counts, and completion flags. Raw source payloads remain under `raw/`; counts and interpretations remain outside that directory.

## Source inventory and terms

The CVE Program identifies `cvelistV5` release assets as its official bulk-download route; daily baselines contain all current CVE records at midnight UTC. [1] GitHub’s advisory repository says records are stored in OSV format and that the repository is licensed CC BY 4.0; preserve attribution and check record provenance. [2] OSV documents `all.zip` as a full export across ecosystems, including withdrawn records, while noting that licensing varies by upstream source. [3] NVD documents API pagination, incremental modified-date retrieval, and rate limits; requests were paced accordingly. [4] [5]

## Next acquisition priorities

1. Maintain NVD from the saved modified-date cursor; retain overlapping update windows and reconcile each page set to a fresh API total.
2. Capture future CVE List V5 daily baselines or hourly deltas as immutable releases with revisions and digests.
3. Track OSV `modified_id.csv` for incremental changes and retain each full archive generation used as a baseline.
4. Enrich selected records with primary vendor/project advisories, exact fixing commits, patch diffs, regression tests, and source licenses.
5. Expand source coverage to CWE/CAPEC, CVE history and corrections, vendor CNA advisories, and historical research datasets, recording access failures and terms.

## References

[1]: https://www.cve.org/downloads "CVE List downloads and baseline assets"
[2]: https://github.com/github/advisory-database "GitHub Advisory Database repository, format, and license"
[3]: https://google.github.io/osv.dev/data/ "OSV data sources and full database exports"
[4]: https://nvd.nist.gov/developers/start-here "NVD API rate limits and best practices"
[5]: https://nvd.nist.gov/developers/vulnerabilities "NVD Vulnerability API pagination documentation"
