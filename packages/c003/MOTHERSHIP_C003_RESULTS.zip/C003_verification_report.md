# C-003 Verification Report

**Verdict: CONDITIONAL PASS**

This cycle used only files already preserved in C-002; no vulnerability data was newly acquired and no C-002 file was modified. The six result artifacts are regenerated from those saved bytes.

## VERIFIED — reproducible from preserved bytes

- **217/217 original raw files:** each file was re-read. The attached integrity JSONL gives actual and expected byte counts, calculated and expected SHA-256 digests, and PASS/FAIL for every path. 217/217 pass; 0 fail. Expected values are cross-checked between the C-002 raw-file manifest and `SHA256SUMS.txt`.
- **Full C-002 handoff archive:** 3,659,552,713 bytes were read and SHA-256 `14738da2fc7d0dd0ea9cb36f9dd3b7b618344fbc3fe3103d8719c8d4c4dabf62` matches the supplied sidecar `14738da2fc7d0dd0ea9cb36f9dd3b7b618344fbc3fe3103d8719c8d4c4dabf62` (**PASS**). The sidecar match verifies byte equality, not the sidecar's external authenticity.
- **NVD page retrieval coverage:** 209 saved pages were parsed, with 416,844 records and 416,844 unique CVE IDs; 0 duplicate IDs; 0 missing and 0 unexpected start indices; 0 page-payload errors. First/last response totals: 416,807/416,844; the separate preserved reconciliation response reports 416,844. Final-page count 844 equals final remaining count 844. Thus complete retrieval against the last reported total is **VERIFIED**. This does not establish a point-in-time snapshot.
- **CVE List V5:** recomputed 416,267 record files / 416,267 unique CVE IDs; 0 duplicate IDs; states {'PUBLISHED': 397425, 'REJECTED': 18842}; ZIP CRC/record parse errors 0. Archive bytes and SHA-256 match the preserved C-002 manifests: PASS.
- **GitHub Advisory Database:** recomputed 397,466 advisory JSON files / 397,466 unique GHSA IDs; 1,250 withdrawn; 0 parse/read errors. Archive bytes and SHA-256 match the preserved C-002 manifests: PASS.
- **OSV:** recomputed 2,332,672 JSON records / 2,332,672 unique IDs; 107,552 withdrawn; 0 parse/CRC errors. Archive bytes and SHA-256 match the preserved C-002 manifests: PASS; locally recalculated MD5 matches the C-002 reported upstream value: True.
- **20-record sample:** the deterministic selection was recomputed from the parsed source identifier sets and matches the preserved sample IDs in order: True. Four presence strata contributed five IDs each. All 20 are in CVE List and NVD; 10 are in GitHub and 10 in OSV. Their source records were freshly extracted from the saved C-002 archives/pages. Per-ID differences are retained in `C003_cross_source_sample.jsonl`.

## REPORTED — present in C-002 metadata, not treated as independently proven by a local parse

C-002 records the CVE List release tag `cve_2026-10-29_2300Z`, GitHub advisory commit `1cffb381571b702172a31eff57809b3d0fa1e13f`, and OSV object generation `1793326731605169`. These are preserved metadata assertions. The GitHub SHA names a commit, but without the Git object/tree evidence it does not by itself bind the delivered tar archive to that commit. The OSV generation is recorded alongside the archive; its local checksum and counts are independently recomputed above.

## UNVERIFIED — limitations and unresolved discrepancies

1. **NVD atomic point-in-time consistency:** the page total changed from 416,807 to 416,844 while pagination was in progress. All expected pages and the final total reconcile, but the saved pages may represent a moving dataset. Closure requires a frozen NVD snapshot or exact same-set reconciliation under a stable snapshot identifier.
2. **GitHub archive-to-commit binding:** the raw tar SHA is reproducible and matches C-002's expected hash, but the handoff lacks a Git bundle/tree object that proves those bytes correspond to the reported commit. C-002's metadata says a shallow object store was retained, while none is present in the delivered handoff. Closure requires that object/tree proof or a trusted acquisition-time digest tied to the commit.
3. **Checksum trust anchor:** the supplied full-handoff sidecar and internal manifests agree with the preserved bytes. They are checksums, not signatures; a trusted signature or custodian attestation would be needed to independently establish their external authenticity.
4. **Sample discrepancies:** 53 unresolved source-difference flags affect 20 sampled identifiers. Each JSONL row provides exact status, affected-product/package, and severity claims by source, plus evidence needed for source-aware review. These differences are not automatically contradictions because fields/scopes may not be equivalent.

## Output inventory

The compact ZIP contains exactly the six requested result files: integrity JSONL, NVD reconciliation JSON, archive validation JSON, cross-source sample JSONL, this report, and unresolved-findings JSON. See `C003_unresolved.json` for the itemized closure evidence.
