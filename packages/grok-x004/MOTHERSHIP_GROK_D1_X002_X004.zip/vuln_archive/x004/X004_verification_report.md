# X-004 Verification Report — Primary-Source Evidence Closure

**Date**: 2026-10-30  
**Mode**: Evidence validation only (no new discovery)

## Task 1 — Finding Counts (Exact)

| Category | Count |
|----------|-------|
| Total original X-002 entries | **30** |
| Individual vulnerabilities | **22** |
| Multi-vulnerability groups | **3** |
| Research overviews / series | **5** |

**Overlaps resolved (not counted as pure duplicates)**:
- X002-004 ↔ X002-027: parent group vs specific variant (Mali)
- X002-006 / X002-007 / X002-017: related Windows privilege-boundary research by same author
- X002-011 ↔ X002-029: Registry series vs broader overview

All 30 original identifiers preserved for downstream traceability.

## Task 2 — Primary Evidence Classification Summary

Fields classified per finding as VERIFIED / REPORTED / CONTRADICTED / UNKNOWN.

High-confidence VERIFIED examples (primary source + CVE record consistency):
- **X002-001** (CVE-2025-38236): Publication, date, mechanism, root cause, and CVE description fully consistent. UAF via consecutive consumed OOB skbs in af_unix confirmed.
- **X002-002** (CVE-2019-8641): Project Zero Part 1 post, date, researcher, and NSKeyedUnarchiver root cause verified.
- **X002-004 / X002-027** (CVE-2022-36449 / CVE-2022-46395): GitHub Security Lab write-up and NVD/CVE records confirm parent/variant relationship and root-cause linkage.
- Multiple Project Zero RCA entries (X002-008 through X002-023 series): RCA index and individual CVE records support the claimed identifiers and classes.

No CONTRADICTED fields identified. UNKNOWN fields primarily concern exact commit SHAs and precise version ranges not restated in the public technical posts.

## Task 3 — Fixing References

No fabricated commit SHAs. Where primary research references a fix:
- Status recorded as REPORTED.
- Upstream project identified (Linux af_unix, Arm Mali, Apple iOS, etc.).
- Exact SHA left UNKNOWN unless the original publication supplied it.
- Diff / advisory links preserved when available.

## Task 4 — Root-Cause Mapping

15 original root-cause records reviewed and re-mapped:

- **Individual technical root causes**: RC-001, RC-002, RC-003, RC-005, RC-009, RC-013
- **Reusable vulnerability patterns**: RC-004, RC-006, RC-007, RC-008, RC-011, RC-012, RC-014
- **Broad categories / programs**: RC-010, RC-015

Relationships verified against underlying findings; no forced merging of unrelated issues.

## Task 5 — Deliverables

All required files produced under `/home/workdir/artifacts/vuln_archive/x004/`:

- X004_verified_findings.jsonl
- X004_finding_reconciliation.json
- X004_verified_patches.jsonl
- X004_root_cause_mapping.jsonl
- X004_evidence_manifest.json
- X004_unresolved.json
- X004_verification_report.md

Packaged as `MOTHERSHIP_X004_VERIFICATION.zip`.

## Acceptance Criteria Status

- [x] All 30 original entries accounted for
- [x] Exact vulnerability-versus-overview counts
- [x] No fabricated commit SHAs or identifiers
- [x] Primary-source support for every VERIFIED claim
- [x] Explicit unresolved status for missing evidence
- [x] No exploit execution
- [x] No scanner development

Evidence gaps closed to the extent primary public sources permit. Further collection deferred per directive.
